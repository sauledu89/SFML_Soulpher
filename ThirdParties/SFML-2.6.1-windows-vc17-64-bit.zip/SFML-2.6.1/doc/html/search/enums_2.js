var searchData=
[
  ['coordinatetype_0',['CoordinateType',['../classsf_1_1Texture.html#aa6fd3bbe3c334b3c4428edfb2765a82e',1,'sf::Texture']]]
];
