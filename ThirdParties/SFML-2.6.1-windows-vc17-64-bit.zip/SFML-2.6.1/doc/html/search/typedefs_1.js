var searchData=
[
  ['constiterator_0',['ConstIterator',['../classsf_1_1String.html#a8e18efc2e8464f6eb82818902d527efa',1,'sf::String']]]
];
