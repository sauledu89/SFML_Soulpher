var searchData=
[
  ['position_0',['position',['../classsf_1_1Vertex.html#a8a4e0f4dfa7f1eb215c92e93d04f0ac0',1,'sf::Vertex::position()'],['../structsf_1_1Event_1_1JoystickMoveEvent.html#aba5a70815420161375fd2e756689c32a',1,'sf::Event::JoystickMoveEvent::position()']]],
  ['productid_1',['productId',['../structsf_1_1Joystick_1_1Identification.html#a18c21317789f51f9a5f132677727ff77',1,'sf::Joystick::Identification']]]
];
