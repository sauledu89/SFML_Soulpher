var searchData=
[
  ['r_0',['r',['../classsf_1_1Color.html#a6a5256ca24a4f9f0e0808f6fc23e01e1',1,'sf::Color']]],
  ['red_1',['Red',['../classsf_1_1Color.html#a127dbf55db9c07d0fa8f4bfcbb97594a',1,'sf::Color']]],
  ['rsbdelta_2',['rsbDelta',['../classsf_1_1Glyph.html#affcf288079ac470f2d88765bbfef93fa',1,'sf::Glyph']]]
];
